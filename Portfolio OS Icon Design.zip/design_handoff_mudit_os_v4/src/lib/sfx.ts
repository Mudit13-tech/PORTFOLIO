/** Quiet synthesized UI sounds. No audio files. Gate with the user's sound setting. */
export type Sfx = 'press' | 'release' | 'tick' | 'open' | 'close' | 'min'

let ac: AudioContext | null = null
export let soundOn = true
export const setSound = (on: boolean) => { soundOn = on }

export function sfx(kind: Sfx) {
  if (!soundOn || typeof window === 'undefined') return
  try {
    const A = ac || (ac = new (window.AudioContext || (window as any).webkitAudioContext)())
    if (A.state === 'suspended') A.resume()
    const t = A.currentTime + 0.004
    const noise = (dur: number, f0: number, f1: number, vol: number, q = 0.8) => {
      const n = Math.floor(A.sampleRate * dur), b = A.createBuffer(1, n, A.sampleRate), c = b.getChannelData(0)
      for (let i = 0; i < n; i++) c[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / n, 2)
      const s = A.createBufferSource(), f = A.createBiquadFilter(), g = A.createGain()
      s.buffer = b; f.type = 'bandpass'; f.Q.value = q
      f.frequency.setValueAtTime(f0, t); f.frequency.exponentialRampToValueAtTime(f1, t + dur)
      g.gain.value = vol; s.connect(f); f.connect(g); g.connect(A.destination); s.start(t)
    }
    const tone = (fr: number, dur: number, vol: number) => {
      const o = A.createOscillator(), g = A.createGain(); o.frequency.value = fr
      g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur)
      o.connect(g); g.connect(A.destination); o.start(t); o.stop(t + dur)
    }
    if (kind === 'press') noise(0.03, 3200, 2200, 0.35, 2)
    if (kind === 'release') { noise(0.025, 4200, 3000, 0.22, 2); tone(1900, 0.05, 0.015) }
    if (kind === 'tick') noise(0.015, 5000, 4000, 0.06, 3)
    if (kind === 'open') noise(0.28, 500, 2600, 0.12, 0.7)
    if (kind === 'close') noise(0.22, 2400, 500, 0.1, 0.7)
    if (kind === 'min') noise(0.34, 1800, 300, 0.1, 0.7)
  } catch {}
}
