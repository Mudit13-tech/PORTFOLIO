'use client'
import { useEffect, useRef } from 'react'
import { mountWallpaper } from '@/lib/wallpaper'

/** Live WebGL silk gradient. Sits behind the desk (z-index 0). */
export function Wallpaper({ mode, animate = true }: { mode: 'light' | 'dark'; animate?: boolean }) {
  const ref = useRef<HTMLCanvasElement>(null)
  const wall = useRef<{ setMode(m: string): void; destroy(): void } | null>(null)

  useEffect(() => {
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    wall.current = mountWallpaper(ref.current!, { mode, animate: animate && !reduce })
    return () => wall.current?.destroy()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [animate])

  useEffect(() => { wall.current?.setMode(mode) }, [mode])

  return <canvas ref={ref} aria-hidden className="wallpaper-canvas" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', display: 'block' }} />
}
