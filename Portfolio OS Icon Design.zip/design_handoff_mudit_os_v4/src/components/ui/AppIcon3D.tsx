'use client'
import { createContext, useContext, useEffect, useRef, useState, type ReactNode } from 'react'
import type { AppId } from '@/os/types'
import { sfx } from '@/lib/sfx'

type Frames = Record<AppId, string[]>
const Ctx = createContext<Frames | null>(null)
let cache: Frames | null = null

/** Renders all nine 3D icons once (≈1–2s), client-side, and shares the frames. Mount once in Shell. */
export function IconFramesProvider({ children }: { children: ReactNode }) {
  const [frames, setFrames] = useState<Frames | null>(cache)
  useEffect(() => {
    if (cache) return
    import('@/lib/icons3d').then((m) => m.renderIcons({ size: 256, frames: 16 })).then((f: Frames) => { cache = f; setFrames(f) })
  }, [])
  return <Ctx.Provider value={frames}>{children}</Ctx.Provider>
}

/**
 * One app icon. Idle = frame 0. Hover plays the 16-frame turn at 55ms/frame
 * and eases back to frame 0 at 40ms/frame on leave. Press scales to .9.
 * `bounce` — increment to play the dock launch bounce.
 */
export function AppIcon3D({ id, bounce = 0 }: { id: AppId; bounce?: number }) {
  const frames = useContext(Ctx)?.[id]
  const [f, setF] = useState(0)
  const [hov, setHov] = useState(false)
  const [press, setPress] = useState(false)
  const outer = useRef<HTMLDivElement>(null)
  const timer = useRef<ReturnType<typeof setInterval>>()
  const first = useRef(true)

  useEffect(() => () => clearInterval(timer.current), [])
  useEffect(() => {
    if (first.current) { first.current = false; return }
    if (!bounce) return
    outer.current?.animate(
      [{ transform: 'translateY(0)' }, { transform: 'translateY(-30%)', offset: 0.3 }, { transform: 'translateY(0)', offset: 0.55 }, { transform: 'translateY(-10%)', offset: 0.75 }, { transform: 'translateY(0)' }],
      { duration: 760, easing: 'cubic-bezier(.3,0,.3,1)' },
    )
  }, [bounce])

  const enter = () => {
    setHov(true); clearInterval(timer.current)
    if (frames) timer.current = setInterval(() => setF((x) => (x + 1) % frames.length), 55)
  }
  const leave = () => {
    setHov(false); setPress(false); clearInterval(timer.current)
    if (!frames) return
    timer.current = setInterval(() => setF((x) => { if (x === 0) { clearInterval(timer.current); return 0 } return (x + 1) % frames.length }), 40)
  }

  return (
    <div ref={outer} style={{ width: '100%', height: '100%' }}>
      <div
        onPointerEnter={enter}
        onPointerLeave={leave}
        onPointerDown={() => { setPress(true); sfx('press') }}
        onPointerUp={() => { if (press) { setPress(false); sfx('release') } }}
        style={{
          width: '100%', height: '100%',
          transition: 'transform .28s cubic-bezier(.2,.9,.3,1.2), filter .28s',
          transform: press ? 'scale(.9)' : hov ? 'scale(1.06) translateY(-2px)' : 'none',
          filter: hov ? 'brightness(1.06)' : 'none',
        }}
      >
        {frames
          ? <img src={frames[f]} alt="" draggable={false} style={{ width: '100%', height: '100%', display: 'block', userSelect: 'none', pointerEvents: 'none' }} />
          : <div className="icon-shimmer" style={{ width: '78%', height: '78%', margin: '11%', borderRadius: '24%', background: 'rgba(255,255,255,.35)' }} />}
      </div>
    </div>
  )
}
