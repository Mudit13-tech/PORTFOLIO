# Handoff: MUDIT OS v4 — studio-object icons + silk wallpaper

Target repo: `Mudit13-tech/PORTFOLIO` (Next.js App Router, TypeScript).

## Quick start with Claude Code
Unzip this folder at the repo root, then in Claude Code run:

> Read `design_handoff_mudit_os_v4/README.md` and implement it. Move the files in `design_handoff_mudit_os_v4/src/` into `src/`, wire them into the existing shell as described, keep all existing behavior (routes, store, drag, snap, shortcuts, boot, mobile shell), run `npm run build`, then commit and push to `main`.

## Overview
The visual layer of the desktop is replaced:
- **Icons**: every app icon is a real three.js 3D object, studio-lit and rendered in the browser into 16 PNG frames (256px). Hover plays the frames as a small turn in the light.
- **Wallpaper**: a live WebGL "silk" gradient in teal → violet that drifts slowly. It has light and dark palettes.
- **Chrome**: frosted menu bar, frosted dock with spring magnification, and frosted windows that grow from the icon you clicked and shrink back into the dock.

Window *content* stays as it is in the repo. The prototype only shows placeholders there.

## About the design files
`reference/MUDIT OS v4.dc.html` is a **design reference built in HTML** (open it in a browser from inside `reference/`). Don't ship it. Recreate it in the repo's existing components. `src/lib/icons3d.js`, `src/lib/wallpaper.js`, `src/lib/sfx.ts`, `src/components/ui/AppIcon3D.tsx` and `src/components/shell/Wallpaper.tsx` are close to production. Drop them in and adjust imports.

## Fidelity
High-fidelity. Match the colors, sizes, timings and easings below exactly.

## Dependencies
- `npm i three` and `npm i -D @types/three`
- In `src/lib/icons3d.js`, change the first line to `import * as THREE from 'three'`. Optionally rename it to `.ts`.
- Both `icons3d` and `wallpaper` are client-only. Import them only inside `useEffect` or with a dynamic `import()`, never at module top level in server components.

## Files → where they go
| Handoff file | Repo action |
|---|---|
| `src/lib/icons3d.js` | new. `renderIcons({size, frames}) → Promise<Record<AppId, string[]>>` (data-URL PNGs) |
| `src/lib/wallpaper.js` | new. `mountWallpaper(canvas, {mode, animate}) → {setMode, destroy}` |
| `src/lib/sfx.ts` | new. Call `setSound()` from the existing sound/settings state if there is one |
| `src/components/ui/AppIcon3D.tsx` | new. Replaces `AppIcon` in `src/components/ui/index.tsx` wherever an app icon is drawn (desk, dock, window title, launcher, mobile home) |
| `src/components/shell/Wallpaper.tsx` | new. Render it inside `Desk.tsx` as the bottom layer. Remove or neutralise the `.wallpaper` background in `globals.css` |
| `DesktopIcons.tsx`, `Dock.tsx`, `Window.tsx`, `MenuBar.tsx` | restyle per the specs below |
| `Shell.tsx` | wrap in `<IconFramesProvider>` |

## Screens / components

### Desk
Full viewport, `overflow: hidden`. The wallpaper canvas is at the bottom (`position:absolute; inset:0`). The fallback background before WebGL paints is `#20302e`.

### Menu bar (`TOP_BAR_H = 30`)
- Height 30px, padding `0 14px`, gap 20px, 13px Geist 500.
- `backdrop-filter: blur(24px) saturate(1.6)`
- Light: bg `rgba(248,248,246,.55)`, bottom `1px solid rgba(0,0,0,.07)`, ink `#15181b`
- Dark: bg `rgba(18,22,24,.5)`, bottom `1px solid rgba(255,255,255,.07)`, ink `#eceeec`
- "MUDIT OS" is weight 700 with letter-spacing .04em. The clock is Geist Mono 12px.

### Desktop icons
- Grid anchored top-right: `right:14px; top:42px`, 2 columns of 100px, row-gap 4px, in `APP_ORDER`.
- Each item is a button with padding `6px 0`, a column with gap 4px, radius 10px.
- Icon 66×66.
- Label (`APP_LABEL`): Geist 600 10.5px, letter-spacing .06em, color ink, text-shadow `0 1px 2px rgba(255,255,255,.7)` (light) or `0 1px 4px rgba(0,0,0,.7)` (dark).
- Count line: Geist Mono 400 10px, "N items" or blank (min-height 12px), color ink2 = ink at 55%.

### Dock
- Centered, `bottom:10px`. Container: flex, align-items flex-end, gap 6px, padding `6px 10px 12px`, radius 24px, `backdrop-filter: blur(30px) saturate(1.7)`.
  - Light: bg `rgba(255,255,255,.34)`, shadow `inset 0 0 0 .5px rgba(255,255,255,.7), 0 0 0 .5px rgba(0,0,0,.12), 0 16px 40px -14px rgba(20,40,40,.4)`
  - Dark: bg `rgba(40,44,48,.38)`, shadow `inset 0 0 0 .5px rgba(255,255,255,.16), 0 0 0 .5px rgba(0,0,0,.5), 0 16px 40px -14px rgba(0,0,0,.7)`
- Items: every app except `bin` in `APP_ORDER`, then a 1px separator (`margin:6px 3px`, `rgba(0,0,0,.14)` light / `rgba(255,255,255,.16)` dark), then `bin`.
- Rest size 54×54.
- **Magnification**: each frame, `d = |mouseX − itemRestCenterX|` and `f = smoothstep(max(0, 1 − d/160))`. Target size is `54 + 26·f`. Each item runs a spring toward its target with stiffness 420, damping 30 and `dt` capped at 33ms. Write width/height straight to the DOM, not through React state. Measure rest centers on `mouseenter`.
- Tooltip: only on the item with the largest `f` above .55. It sits 12px above the icon, padding `4px 10px`, radius 7px, Geist 500 12px, bg `rgba(250,250,248,.85)` / `rgba(36,40,44,.85)`, blur 20px, fade .15s. Label is `APP_LABEL` in sentence case. Play `sfx('tick')` when the hovered item changes.
- Running dot: 4×4, 8px below the icon, ink color, opacity transition .25s.
- Launch bounce: when an app that isn't running opens, increment its `bounce`. The keyframes live in `AppIcon3D` (760ms).

### Window (restyle `Window.tsx`)
- Radius 14px, `backdrop-filter: blur(30px) saturate(1.5)`
  - Light: bg `rgba(250,250,248,.88)`, shadow `0 0 0 .5px rgba(0,0,0,.18), 0 30px 70px -20px rgba(20,40,40,.45)`
  - Dark: bg `rgba(28,31,34,.86)`, shadow `0 0 0 .5px rgba(255,255,255,.14), 0 30px 80px -20px rgba(0,0,0,.8)`
- Title bar: 40px tall (update `CHROME_H` from 34 to 40), padding `0 14px`, 1px hairline bottom border (same as the menu bar).
- Traffic lights: 12px circles with gap 8px, close `#ec6a5e`, minimise `#f4bf4f`, zoom `#62c554`, each with `inset 0 0 0 .5px rgba(0,0,0,.25)` and `brightness(.9)` on hover.
- Centered title: 20px `AppIcon3D`, then `APP_TITLE` in Geist Mono 500 12px, letter-spacing .04em.
- Existing window body content goes below. The prototype header (84px icon, 26px/600 label and mono meta) is optional.

## Interactions & motion
- **Open** (from desk icon or dock): FLIP from the clicked icon's rect to the window rect. Keyframes `translate(dx,dy) scale(sx,sy)`, opacity 0, blur(4px) → opacity 1 at offset .25 → none. 460ms, `cubic-bezier(.2,.9,.25,1)`. `sfx('open')`.
- **Close**: FLIP to the app's dock item, fading to opacity 0 with blur(3px). 340ms, `cubic-bezier(.5,0,.75,.3)`, fill forwards, then remove the window. `sfx('close')`. The running dot turns off.
- **Minimise**: genie-ish: none → `translate(.25dx,.7dy) scale(.55,.3)` at .55 → dock item rect, opacity .1. 520ms, same easing. `sfx('min')`. The running dot stays on.
- Ignore clicks while an animation is running.
- Icon hover: scale 1.06, translateY(-2px), brightness 1.06, plus the frame turn. Press: scale .9. Transition .28s `cubic-bezier(.2,.9,.3,1.2)`.
- **Loading**: until frames are ready, icons show a shimmering rounded square (78% size, radius 24%, `rgba(255,255,255,.35)`, opacity .35↔.7 over 1.4s). Add `@keyframes` in `globals.css` under `.icon-shimmer`.
- **Reduced motion**: wallpaper renders one still frame and the dock skips magnification. Consider replacing the FLIP with a 150ms fade.

## State
Reuse the existing `store.ts` (windows, focus, z-order). Add:
- `bounce: Record<AppId, number>`
- `soundOn: boolean` (persist with `persist.ts`)
- `mode` already comes from `theme.ts`. Pass it to `<Wallpaper mode>` and to the chrome styles.

## Design tokens
- Fonts: **Geist** 400/500/600/700 and **Geist Mono** 400/500 (`next/font/google` or the `geist` package)
- Ink: `#15181b` light, `#eceeec` dark. ink2 is ink at 55%.
- Hairline: `rgba(0,0,0,.07)` light, `rgba(255,255,255,.07)` dark
- Radii: window 14, dock 24, desk item 10, tooltip 7
- Wallpaper palette (see `wallpaper.js` `pal()`)
  - light: `#edefeb → #94d6bd → #2e9485 → #665cc7 → #edbde0`
  - dark: `#080d12 → #0f383d → #296b61 → #47428c → #9e85db`
- Icon object colors: folder `#3fae86`/`#2f8a6a`, cone `#ff5a2a`, crystal `#7d6cff`, flask liquid `#ffa51f`, monitor `#3a8db0` with trace `#7dffb0`, others in `icons3d.js`

## Assets
There are no image files. All icons are generated at runtime by `icons3d.js` (about 1–2s the first time, cached in memory after that). For faster first paint you can pre-render them at build time: call `renderIcons()` once in a browser, save the PNGs to `public/icons/<id>/<n>.png`, and point `AppIcon3D` at those paths. The flask (`experiments`) and envelope (`contact`) models are the weakest and may be refined later.

## Performance
- The wallpaper renders at 0.75× device pixel ratio (capped at 1.5). Pause it on `visibilitychange`.
- The icon render uses a single WebGL context and releases it after rendering. Don't mount a live three.js scene per icon.
