const FRAG = `
precision highp float;
uniform vec2 R; uniform float T; uniform float D;
float h(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
float n(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);
 return mix(mix(h(i),h(i+vec2(1,0)),f.x),mix(h(i+vec2(0,1)),h(i+vec2(1,1)),f.x),f.y);}
float fbm(vec2 p){float v=0.,a=.5;for(int i=0;i<3;i++){v+=a*n(p);p=p*2.02+vec2(1.7,9.2);a*=.5;}return v;}
float field(vec2 uv){
 vec2 q=vec2(fbm(uv*.55+vec2(0.,T*.015)),fbm(uv*.55+vec2(5.2,1.3)-T*.012));
 vec2 r=vec2(fbm(uv*.6+1.6*q+vec2(1.7,9.2)),fbm(uv*.6+1.6*q+vec2(8.3,2.8)+T*.008));
 return fbm(uv*.45+2.*r)*1.15+.18*uv.y-.1*uv.x+.05*sin(uv.x*2.3+uv.y*1.7);
}
vec3 pal(float t){
 vec3 a,b,c,d,e;
 if(D>.5){a=vec3(.03,.05,.07);b=vec3(.06,.22,.24);c=vec3(.16,.42,.38);d=vec3(.28,.26,.55);e=vec3(.62,.52,.86);}
 else{a=vec3(.93,.94,.92);b=vec3(.58,.84,.74);c=vec3(.18,.58,.52);d=vec3(.40,.36,.78);e=vec3(.93,.74,.88);}
 t=clamp(t,0.,1.);
 if(t<.25)return mix(a,b,t/.25);
 if(t<.5)return mix(b,c,(t-.25)/.25);
 if(t<.75)return mix(c,d,(t-.5)/.25);
 return mix(d,e,(t-.75)/.25);
}
void main(){
 vec2 uv=gl_FragCoord.xy/R.y; uv.x+=.2;
 float e=.004, f=field(uv);
 float fx=field(uv+vec2(e,0.))-f, fy=field(uv+vec2(0.,e))-f;
 vec3 nrm=normalize(vec3(-fx/e*.11,-fy/e*.11,1.));
 vec3 L=normalize(vec3(-.5,.6,.65));
 float diff=clamp(dot(nrm,L),0.,1.), spec=pow(clamp(dot(reflect(-L,nrm),vec3(0,0,1)),0.,1.),40.);
 float t=smoothstep(.3,.86,f);
 vec3 col=pal(t);
 col*=mix(.62,1.14,diff);
 col+=spec*(D>.5?.22:.35);
 vec2 c=gl_FragCoord.xy/R-.5; col*=1.-dot(c,c)*(D>.5?.7:.25);
 col+=(h(gl_FragCoord.xy+T)-.5)*.025;
 gl_FragColor=vec4(col,1.);
}`;
const VERT = 'attribute vec2 p;void main(){gl_Position=vec4(p,0.,1.);}';

export function mountWallpaper(canvas, opts = {}) {
  const gl = canvas.getContext('webgl', { antialias: false, preserveDrawingBuffer: true });
  if (!gl) return { setMode() {}, destroy() {} };
  const sh = (t, s) => { const o = gl.createShader(t); gl.shaderSource(o, s); gl.compileShader(o); return o; };
  const pr = gl.createProgram();
  gl.attachShader(pr, sh(gl.VERTEX_SHADER, VERT)); gl.attachShader(pr, sh(gl.FRAGMENT_SHADER, FRAG));
  gl.linkProgram(pr); gl.useProgram(pr);
  const b = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, b);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
  const loc = gl.getAttribLocation(pr, 'p'); gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
  const uR = gl.getUniformLocation(pr, 'R'), uT = gl.getUniformLocation(pr, 'T'), uD = gl.getUniformLocation(pr, 'D');
  let dark = opts.mode === 'dark' ? 1 : 0, raf = 0, t0 = performance.now(), live = opts.animate !== false;
  const draw = (now) => {
    const w = canvas.clientWidth, h = canvas.clientHeight, s = Math.min(1.5, window.devicePixelRatio || 1) * 0.75;
    if (canvas.width !== Math.round(w * s) || canvas.height !== Math.round(h * s)) { canvas.width = Math.round(w * s); canvas.height = Math.round(h * s); }
    gl.viewport(0, 0, canvas.width, canvas.height);
    gl.uniform2f(uR, canvas.width, canvas.height); gl.uniform1f(uT, 8 + (now - t0) / 1000); gl.uniform1f(uD, dark);
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    if (live) raf = requestAnimationFrame(draw);
  };
  const once = live; live = false; draw(performance.now()); live = once;
  if (live) raf = requestAnimationFrame(draw);
  return {
    setMode(m) { dark = m === 'dark' ? 1 : 0; const l = live; live = false; draw(performance.now()); live = l; },
    destroy() { cancelAnimationFrame(raf); live = false; },
  };
}
