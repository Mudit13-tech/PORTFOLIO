import * as THREE from 'https://unpkg.com/three@0.184.0/build/three.module.js';

const std = (name, o) => Object.assign(new THREE.MeshStandardMaterial(o), { name });
const phys = (name, o) => Object.assign(new THREE.MeshPhysicalMaterial(o), { name });
const mesh = (name, g, m) => { const x = new THREE.Mesh(g, m); x.name = name; x.castShadow = true; x.receiveShadow = true; return x; };

function rrShape(w, h, r) {
  const s = new THREE.Shape(), x = -w / 2, y = -h / 2;
  s.moveTo(x + r, y); s.lineTo(x + w - r, y); s.quadraticCurveTo(x + w, y, x + w, y + r);
  s.lineTo(x + w, y + h - r); s.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  s.lineTo(x + r, y + h); s.quadraticCurveTo(x, y + h, x, y + h - r);
  s.lineTo(x, y + r); s.quadraticCurveTo(x, y, x + r, y);
  return s;
}
function ext(shape, d, b = 0.02) {
  const g = new THREE.ExtrudeGeometry(shape, { depth: Math.max(0.001, d - 2 * b), bevelEnabled: b > 0, bevelSize: b, bevelThickness: b, bevelSegments: 5, curveSegments: 16 });
  g.center(); g.computeVertexNormals(); return g;
}
const rbox = (w, h, d, r = 0.06, b = 0.02) => ext(rrShape(w, h, r), d, b);
const lathe = (pts, seg = 64) => new THREE.LatheGeometry(pts.map(([x, y]) => new THREE.Vector2(x, y)), seg);

const B = {
  projects() {
    const g = new THREE.Group();
    const teal = std('folder', { color: 0x3fae86, roughness: 0.42 });
    const tealD = std('folder_back', { color: 0x2f8a6a, roughness: 0.5 });
    const paper = std('paper', { color: 0xf6f3ec, roughness: 0.85 });
    const s = new THREE.Shape();
    s.moveTo(-0.8, -0.55); s.lineTo(0.8, -0.55); s.lineTo(0.8, 0.45); s.lineTo(-0.12, 0.45); s.lineTo(-0.22, 0.6); s.lineTo(-0.8, 0.6); s.closePath();
    g.add(mesh('back', ext(s, 0.05, 0.02), tealD));
    const p1 = mesh('paper1', new THREE.BoxGeometry(1.42, 0.98, 0.01), paper); p1.position.set(0.02, 0.06, 0.05); p1.rotation.z = 0.04; g.add(p1);
    const p2 = mesh('paper2', new THREE.BoxGeometry(1.42, 0.98, 0.01), paper); p2.position.set(-0.03, 0.1, 0.07); p2.rotation.z = -0.05; g.add(p2);
    const f = mesh('front', rbox(1.64, 0.92, 0.05, 0.05, 0.02), teal); f.position.set(0, -0.1, 0.13); f.rotation.x = -0.16; g.add(f);
    g.rotation.set(-0.35, 0.5, 0); return g;
  },
  failures() {
    const g = new THREE.Group();
    const orange = std('cone', { color: 0xff5a2a, roughness: 0.45 });
    const white = std('reflective', { color: 0xf4f4f0, roughness: 0.25, metalness: 0.1 });
    const base = mesh('base', rbox(1.05, 1.05, 0.1, 0.12, 0.03), std('base', { color: 0xd94a22, roughness: 0.6 })); base.rotation.x = -Math.PI / 2; base.position.y = 0.05; g.add(base);
    const R = y => 0.4 - (y - 0.1) * 0.27;
    g.add(mesh('body', lathe([[0, 1.36], [0.05, 1.36], [0.07, 1.33], [R(0.1), 0.1], [0, 0.1]]), orange));
    [[0.42, 0.6], [0.82, 0.96]].forEach(([a, b], i) => g.add(mesh('band' + i, lathe([[R(a) + 0.006, a], [R(b) + 0.006, b]]), white)));
    g.position.y = -0.7; g.rotation.set(0.1, 0.6, 0); const w = new THREE.Group(); w.add(g); return w;
  },
  skills() {
    const g = new THREE.Group();
    const m = phys('crystal', { color: 0x7d6cff, roughness: 0.08, metalness: 0.15, clearcoat: 1, flatShading: true, iridescence: 0.8, iridescenceIOR: 1.6, envMapIntensity: 1.8, emissive: 0x2a1a80, emissiveIntensity: 0.25 });
    const a = mesh('crystal_a', new THREE.OctahedronGeometry(0.5, 0), m); a.scale.set(1, 1.75, 1); a.rotation.y = 0.4; g.add(a);
    const b = mesh('crystal_b', new THREE.OctahedronGeometry(0.3, 0), m); b.scale.set(1, 1.6, 1); b.position.set(0.55, -0.35, 0.15); b.rotation.set(0, 0.8, -0.35); g.add(b);
    const c = mesh('crystal_c', new THREE.OctahedronGeometry(0.22, 0), m); c.scale.set(1, 1.5, 1); c.position.set(-0.48, -0.5, 0.2); c.rotation.set(0.2, 0.2, 0.4); g.add(c);
    return g;
  },
  experiments() {
    const g = new THREE.Group();
    const glass = phys('glass', { color: 0xe8f4ff, roughness: 0.03, metalness: 0, transparent: true, opacity: 0.32, side: THREE.DoubleSide, clearcoat: 1, envMapIntensity: 2.2, depthWrite: false });
    const liquid = phys('liquid', { color: 0xffa51f, roughness: 0.12, clearcoat: 1, emissive: 0x8a4a00, emissiveIntensity: 0.35 });
    const prof = [[0, 0], [0.5, 0], [0.57, 0.04], [0.6, 0.12], [0.52, 0.34], [0.2, 0.9], [0.14, 1.02], [0.14, 1.32], [0.17, 1.36], [0.17, 1.4]];
    g.add(mesh('flask', lathe(prof), glass));
    g.add(mesh('liquid', lathe([[0, 0.02], [0.48, 0.02], [0.54, 0.06], [0.56, 0.12], [0.46, 0.4], [0, 0.4]]), liquid));
    const cork = mesh('cork', new THREE.CylinderGeometry(0.15, 0.12, 0.2, 32), std('cork', { color: 0xa2744a, roughness: 0.9 })); cork.position.y = 1.44; g.add(cork);
    [[0.12, 0.5, 0.05, 0.05], [-0.08, 0.66, -0.02, 0.035], [0.04, 0.8, 0.03, 0.025]].forEach(([x, y, z, r], i) => { const bb = mesh('bubble' + i, new THREE.SphereGeometry(r, 16, 12), glass); bb.position.set(x, y, z); g.add(bb); });
    g.position.y = -0.72; const w = new THREE.Group(); w.add(g); w.rotation.set(0.12, 0, -0.08); return w;
  },
  monitor() {
    const g = new THREE.Group();
    const body = std('shell', { color: 0x3a8db0, roughness: 0.4 });
    const dark = phys('screen', { color: 0x0b1411, roughness: 0.15, clearcoat: 1 });
    const glow = std('trace', { color: 0x7dffb0, emissive: 0x4dff99, emissiveIntensity: 2.2 });
    g.add(mesh('case', rbox(1.6, 1.12, 0.36, 0.14, 0.05), body));
    const scr = mesh('glass', rbox(1.32, 0.84, 0.03, 0.08, 0.01), dark); scr.position.z = 0.18; g.add(scr);
    const pts = [[-0.55, 0], [-0.25, 0], [-0.15, 0.22], [-0.02, -0.24], [0.1, 0.14], [0.18, 0], [0.55, 0]].map(([x, y]) => new THREE.Vector3(x, y, 0.2));
    g.add(mesh('pulse', new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts, false, 'catmullrom', 0.05), 80, 0.02, 8), glow));
    const neck = mesh('neck', new THREE.CylinderGeometry(0.09, 0.12, 0.3, 32), body); neck.position.y = -0.7; g.add(neck);
    const foot = mesh('foot', new THREE.CylinderGeometry(0.42, 0.46, 0.06, 48), body); foot.position.y = -0.86; g.add(foot);
    g.rotation.set(-0.12, -0.45, 0); return g;
  },
  about() {
    const g = new THREE.Group();
    const card = std('card', { color: 0xf6f3ee, roughness: 0.55 });
    const pur = std('accent', { color: 0x8a67c4, roughness: 0.45 });
    const grey = std('ink', { color: 0xbab4c4, roughness: 0.7 });
    const metal = std('clip', { color: 0xd6d9dc, metalness: 1, roughness: 0.28 });
    g.add(mesh('card', rbox(1.0, 1.4, 0.05, 0.1, 0.02), card));
    const band = mesh('band', rbox(1.0, 0.32, 0.052, 0.1, 0.02), pur); band.position.y = 0.54; g.add(band);
    const av = mesh('avatar', new THREE.CylinderGeometry(0.24, 0.24, 0.03, 48), pur); av.rotation.x = Math.PI / 2; av.position.set(0, 0.12, 0.03); g.add(av);
    [[-0.28, 0.5], [-0.38, 0.34]].forEach(([y, w], i) => { const l = mesh('line' + i, rbox(w, 0.07, 0.02, 0.03, 0.005), grey); l.position.set(0, y, 0.03); g.add(l); });
    const clip = mesh('clip', rbox(0.3, 0.14, 0.08, 0.04, 0.02), metal); clip.position.set(0, 0.74, 0.02); g.add(clip);
    const ring = mesh('ring', new THREE.TorusGeometry(0.09, 0.022, 16, 40), metal); ring.position.set(0, 0.88, 0.02); g.add(ring);
    g.rotation.set(-0.1, 0.45, 0.08); return g;
  },
  contact() {
    const g = new THREE.Group();
    const paper = std('envelope', { color: 0xf4f0e6, roughness: 0.8 });
    const paperD = std('flap', { color: 0xebe5d6, roughness: 0.8 });
    const wax = phys('wax', { color: 0x3475ab, roughness: 0.3, clearcoat: 0.6 });
    g.add(mesh('body', rbox(1.7, 1.1, 0.06, 0.05, 0.02), paper));
    const s = new THREE.Shape(); s.moveTo(-0.83, 0.53); s.lineTo(0.83, 0.53); s.lineTo(0, -0.12); s.closePath();
    const fl = mesh('flap', ext(s, 0.02, 0.008), paperD); fl.position.set(0, 0.2, 0.045); g.add(fl);
    const seal = mesh('seal', new THREE.CylinderGeometry(0.17, 0.18, 0.05, 40), wax); seal.rotation.x = Math.PI / 2; seal.position.set(0, -0.12, 0.07); g.add(seal);
    const dim = mesh('seal_mark', new THREE.TorusGeometry(0.1, 0.018, 12, 32), wax); dim.position.set(0, -0.12, 0.1); g.add(dim);
    g.rotation.set(-0.5, 0.35, 0.12); return g;
  },
  bin() {
    const g = new THREE.Group();
    const steel = std('steel', { color: 0xc4cacf, metalness: 1, roughness: 0.32, side: THREE.DoubleSide });
    const paper = std('crumple', { color: 0xf2efe8, roughness: 0.9, flatShading: true });
    g.add(mesh('can', lathe([[0, 0], [0.4, 0], [0.42, 0.02], [0.52, 1.1], [0.5, 1.1], [0.4, 0.04], [0, 0.04]]), steel));
    [[0.04, 0.42], [1.1, 0.525]].forEach(([y, r], i) => { const t = mesh('rim' + i, new THREE.TorusGeometry(r, 0.022, 12, 64), steel); t.rotation.x = Math.PI / 2; t.position.y = y; g.add(t); });
    for (let i = 0; i < 18; i++) { const a = i / 18 * Math.PI * 2, rib = mesh('rib' + i, new THREE.CylinderGeometry(0.012, 0.012, 1.06, 6), steel); rib.position.set(Math.cos(a) * 0.465, 0.56, Math.sin(a) * 0.465); rib.rotation.set(Math.sin(a) * 0.09, 0, -Math.cos(a) * 0.09); g.add(rib); }
    const ball = new THREE.IcosahedronGeometry(0.3, 2), p = ball.attributes.position;
    for (let i = 0; i < p.count; i++) { const v = new THREE.Vector3().fromBufferAttribute(p, i); v.multiplyScalar(1 + (Math.sin(v.x * 23) * Math.cos(v.y * 19) * Math.sin(v.z * 17)) * 0.18); p.setXYZ(i, v.x, v.y, v.z); }
    ball.computeVertexNormals();
    const b1 = mesh('paper_a', ball, paper); b1.position.set(0.08, 1.08, 0.02); g.add(b1);
    const b2 = mesh('paper_b', ball, paper); b2.scale.setScalar(0.75); b2.position.set(-0.2, 1.12, -0.1); b2.rotation.set(1, 2, 0); g.add(b2);
    g.position.y = -0.62; const w = new THREE.Group(); w.add(g); w.rotation.set(0.28, 0, 0); return w;
  },
  terminal() {
    const g = new THREE.Group();
    const cap = std('keycap', { color: 0x2b3338, roughness: 0.55 });
    const glow = std('legend', { color: 0x8dffb4, emissive: 0x4dff99, emissiveIntensity: 1.8 });
    const geo = ext(rrShape(1.2, 1.2, 0.2), 0.62, 0.1); geo.rotateX(-Math.PI / 2);
    geo.computeBoundingBox(); const bb = geo.boundingBox, p = geo.attributes.position;
    for (let i = 0; i < p.count; i++) { const t = (p.getY(i) - bb.min.y) / (bb.max.y - bb.min.y), s = 1 - 0.2 * t; p.setX(i, p.getX(i) * s); p.setZ(i, p.getZ(i) * s + 0.06 * t); }
    geo.computeVertexNormals();
    g.add(mesh('cap', geo, cap));
    const top = bb.max.y + 0.004;
    const bar = (n, w, x, z, r) => { const m = mesh(n, new THREE.BoxGeometry(w, 0.012, 0.075), glow); m.position.set(x, top, z); m.rotation.y = r; g.add(m); };
    bar('chev_a', 0.26, -0.18, -0.02, -Math.PI / 4); bar('chev_b', 0.26, -0.18, 0.15, Math.PI / 4); bar('under', 0.28, 0.16, 0.24, 0);
    g.rotation.set(0.62, -0.5, 0); return g;
  },
};

function studioEnv(renderer) {
  const s = new THREE.Scene();
  const room = new THREE.Mesh(new THREE.BoxGeometry(12, 12, 12), new THREE.MeshBasicMaterial({ color: 0x5a5d62, side: THREE.BackSide }));
  s.add(room);
  const panel = (w, h, x, y, z, c, i) => { const m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ color: new THREE.Color(c).multiplyScalar(i), side: THREE.DoubleSide })); m.position.set(x, y, z); m.lookAt(0, 0, 0); s.add(m); };
  panel(6, 3, -3, 4, 3, 0xffffff, 5);
  panel(3, 5, 5, 1, -1, 0xfff2e0, 2.5);
  panel(8, 1, 0, -2, 5, 0xffffff, 1.2);
  panel(4, 4, -4, 1, -4, 0xdfe8ff, 1.5);
  const pm = new THREE.PMREMGenerator(renderer);
  return pm.fromScene(s, 0.03).texture;
}

export async function renderIcons({ size = 256, frames = 16 } = {}) {
  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, preserveDrawingBuffer: true });
  renderer.setPixelRatio(1); renderer.setSize(size, size);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.05;
  renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.setClearColor(0x000000, 0);
  const scene = new THREE.Scene();
  scene.environment = studioEnv(renderer);
  const key = new THREE.DirectionalLight(0xffffff, 1.6); key.position.set(-2, 5, 3); key.castShadow = true;
  key.shadow.mapSize.set(1024, 1024); key.shadow.radius = 8; key.shadow.bias = -0.0005;
  Object.assign(key.shadow.camera, { left: -2, right: 2, top: 2, bottom: -2, near: 0.1, far: 12 });
  scene.add(key);
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(8, 8), new THREE.ShadowMaterial({ opacity: 0.28 }));
  ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; scene.add(ground);
  const cam = new THREE.PerspectiveCamera(26, 1, 0.1, 50);
  cam.position.set(0, 1.4, 5.6); cam.lookAt(0, 0.02, 0);
  const out = {};
  for (const id of Object.keys(B)) {
    const obj = B[id](), pivot = new THREE.Group(); pivot.add(obj);
    const box = new THREE.Box3().setFromObject(pivot), sz = box.getSize(new THREE.Vector3()), c = box.getCenter(new THREE.Vector3());
    const k = 2.2 / Math.max(sz.x, sz.y, sz.z * 0.9);
    obj.position.sub(c); pivot.scale.setScalar(k);
    const holder = new THREE.Group(); holder.add(pivot); scene.add(holder);
    const bb2 = new THREE.Box3().setFromObject(holder); ground.position.y = bb2.min.y - 0.002;
    const list = [];
    for (let f = 0; f < frames; f++) {
      holder.rotation.y = Math.sin(f / frames * Math.PI * 2) * 0.5;
      holder.position.y = Math.sin(f / frames * Math.PI * 2 * 2) * 0.015;
      renderer.render(scene, cam);
      list.push(renderer.domElement.toDataURL('image/png'));
    }
    out[id] = list;
    scene.remove(holder);
    await new Promise(r => { const c = new MessageChannel(); c.port1.onmessage = () => r(); c.port2.postMessage(0); });
  }
  renderer.dispose();
  return out;
}
